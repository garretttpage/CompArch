This is the baseline HDL files for the pipelined RV32 RISC-V

Currently, the memory model is written to output little endian. To run
the design through, just type:

vsim -do riscv_pipelined.do -c

or

vsim -do riscv_pipelined.do






