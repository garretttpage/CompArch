These files are used for Laboratory 2 within ECEN 4243 : Computer
Architecture.  The HDL files need a Mentor Graphics (MGC) ModelSim.
Feel free to use whatever system you want to use as the program is
either downloadable from GitHub or within the laboratory. 

For more information on the RISC-V instructions, it is highly advisable
to see the DDCA textbook by S. L. Harris and D. Harris.  

You can compile the test program in the riscvtest directory by typing
make.  If you run the riscvtest.memfile simulation through the
riscvsingle.do DO file and if successful, it should write the value 25
to address 100 and print "Simulation Succeeded" to your transcript window


Should we add RV32i instructions?
Instructions to Add (16?)
xor
sll
srl
bne
lui
sra
lbu
blt
bltu
bge
bgeu
jalr
auipc
sb
slli
srai





